#ifndef TILE_H
#define TILE_H
#include <stdio.h>
#include <string.h>
#include "SDL.h"
#include "SDL_image.h"
#include "WindowProperty.h"

class Tile
{
    public:
        Tile() = default;
        virtual ~Tile();
        void init(std::string name, int x, int y, int h, int w, int weight);
        void render();
        void update();

    private:
<<<<<<< HEAD


=======
>>>>>>> a64b7d03fbfa5d7275f516e8b295f5426af8d7b2
        int x;
        int y;
        int h;
        int w;
        int weight;

        SDL_Rect srcRect,dstRect;
        SDL_Texture* sprite;

};

#endif // TILE_H
