#include "Tile.h"
#include <iostream>
using namespace std;


Tile::~Tile()
{
    SDL_DestroyTexture(this->sprite);
    this->sprite= NULL;
    //dtor
}

<<<<<<< HEAD
void Tile::init(std::string name, int x , int y, float h, float w, int weight){

=======
void Tile::init(std::string name, int x , int y, int h, int w, int weight){
    //numberOfTiles++;
       //cout<<numberOfTiles << endl;

    //    cout<<"this is your xValue:";
    //cout<<x << endl;
    //cout<<"this is your yValue:";
    //cout<<y << endl;
>>>>>>> a64b7d03fbfa5d7275f516e8b295f5426af8d7b2
    this->x = x;
    this->y = y;
    this->w = w;
    this->h = h;
    this->weight = weight;
<<<<<<< HEAD
    cout<<"this is you x value: " << x << endl;
    cout<<"this is you y value: " << y << endl;
    cout<<"this is you w value: " << w << endl;
    cout<<"this is you h value: " << h << endl;

=======
>>>>>>> a64b7d03fbfa5d7275f516e8b295f5426af8d7b2
    SDL_Surface* tempSurface = SDL_LoadBMP(name.c_str());
    this->sprite = SDL_CreateTextureFromSurface(WindowProperty::renderer, tempSurface);
    SDL_FreeSurface(tempSurface);
    this->srcRect.h = 64;
    this->srcRect.w = 64;
    this->dstRect.h = h;
    this->dstRect.w = w;

    this->srcRect.x = 0;
    this->srcRect.y = 0;
    this->dstRect.x = x;
    this->dstRect.y = y;
}

void Tile::render(){
    printf("W:%d H:%d W:%d H:%d\n",this->srcRect.x,this->srcRect.y,this->dstRect.x,this->srcRect.y);
    SDL_RenderCopy(WindowProperty::renderer,this->sprite,&this->srcRect, &this->dstRect);
}

void Tile::update(){
    this->dstRect.h = ceil(h*WindowProperty::getHeightDisposition());
    this->dstRect.w = ceil(w*WindowProperty::getWidthDisposition());
    this->dstRect.x = ceil(((float)x) * WindowProperty::getWidthDisposition());
    this->dstRect.y = ceil(((float)y)* WindowProperty::getHeightDisposition());
}
